import os
import json
from pathlib import Path
from typing import Dict, Any, List
from crewai.tools import BaseTool

# ✅ FIXED: Use the correct path relative to your project root
DATA_PATH = "data/cases.json"


class FileParserTool(BaseTool):
    name: str = "File Parser Tool"
    description: str = """Loads and parses structured legal case data from JSON files.
    Use this tool to search for cases by case_name (e.g., 'Rajkumar' or 'Arun Singh').
    You can provide either the full case name or a partial match."""

    def _run(self, case_name: str) -> str:
        """
        Load case data by case name.
        Args:
            case_name: The name of the case to search for (can be partial)
        Returns:
            Formatted string with all case information
        """
        # Check if file exists
        if not os.path.exists(DATA_PATH):
            current_dir = os.getcwd()
            return f"""ERROR: Data file not found at {DATA_PATH}
            
Current directory: {current_dir}
Full path tried: {os.path.abspath(DATA_PATH)}

Please ensure your cases.json file is in the 'data' folder relative to where you're running the script."""

        try:
            # Load JSON data
            with open(DATA_PATH, 'r', encoding='utf-8') as f:
                cases = json.load(f)

            if not isinstance(cases, list):
                return "ERROR: JSON file should contain a list of cases"

            # Search for matching cases (case-insensitive partial match)
            case_name_lower = case_name.lower().strip()
            matching_cases = [
                case for case in cases 
                if case_name_lower in case.get('case_name', '').lower()
            ]

            if not matching_cases:
                # Get unique case names for helpful error message
                available_cases = sorted(set([
                    case.get('case_name', 'Unknown') 
                    for case in cases
                ]))[:10]
                
                return f"""ERROR: No case found matching '{case_name}'

Available cases (showing first 10):
{chr(10).join(f'  • {name}' for name in available_cases)}

💡 Try using a partial name like:
  - 'Rajkumar'
  - 'Arun Singh'
  - Or copy the exact case name from above"""

            # Format the results
            result_lines = []
            case_title = matching_cases[0].get('case_name', 'Unknown Case')
            judgement_date = matching_cases[0].get('judgement_date', 'N/A')
            
            result_lines.append("="*80)
            result_lines.append(f"📋 CASE: {case_title}")
            result_lines.append(f"📅 JUDGEMENT DATE: {judgement_date}")
            result_lines.append(f"📊 TOTAL ENTRIES: {len(matching_cases)}")
            result_lines.append("="*80)
            result_lines.append("")
            
            # Add all Q&A pairs
            for idx, case in enumerate(matching_cases, 1):
                result_lines.append(f"Entry {idx}:")
                result_lines.append(f"❓ Question: {case.get('question', 'N/A')}")
                result_lines.append(f"✅ Answer: {case.get('answer', 'N/A')}")
                result_lines.append("-" * 80)
                result_lines.append("")

            return "\n".join(result_lines)

        except json.JSONDecodeError as e:
            return f"ERROR: Invalid JSON format in {DATA_PATH}: {str(e)}"
        except Exception as e:
            return f"ERROR: Failed to load case data: {str(e)}"

    async def _arun(self, case_name: str) -> str:
        """Async version of _run"""
        return self._run(case_name)


# ✅ Create an instance to use in agents
file_parser_tool = FileParserTool()


# ============= HELPER FUNCTIONS =============
def list_all_cases(data_path: str = DATA_PATH) -> List[str]:
    """Helper function to get all unique case names"""
    try:
        with open(data_path, 'r', encoding='utf-8') as f:
            cases = json.load(f)
        return sorted(set(case.get('case_name', 'Unknown') for case in cases))
    except Exception as e:
        return [f"Error loading cases: {str(e)}"]


def get_case_count(data_path: str = DATA_PATH) -> int:
    """Get total number of case entries"""
    try:
        with open(data_path, 'r', encoding='utf-8') as f:
            cases = json.load(f)
        return len(cases)
    except:
        return 0


# ============= TEST THE TOOL =============
if __name__ == "__main__":
    print("Testing File Parser Tool")
    print("="*80)
    
    # Check if file exists
    if os.path.exists(DATA_PATH):
        print(f"✅ Found data file: {os.path.abspath(DATA_PATH)}")
        print(f"📊 Total entries: {get_case_count()}")
        print(f"📁 Unique cases: {len(list_all_cases())}")
    else:
        print(f"❌ Data file not found: {os.path.abspath(DATA_PATH)}")
        exit(1)
    
    print("\n" + "="*80)
    print("All available cases:")
    print("="*80)
    for idx, case_name in enumerate(list_all_cases(), 1):
        print(f"{idx}. {case_name}")
    
    print("\n" + "="*80)
    print("Testing search for 'Rajkumar'...")
    print("="*80)
    
    tool = FileParserTool()
    result = tool._run("Rajkumar")
    print(result)
from typing import Type, Dict, Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
import json

class EvidenceAnalyzerInput(BaseModel):
    """Input for evidence analysis."""
    evidence_type: str = Field(..., description="Type of evidence: documentary, testimonial, physical, digital")
    evidence_description: str = Field(..., description="Description of the evidence to analyze")

class EvidenceAnalyzerTool(BaseTool):
    name: str = "Evidence Analyzer"
    description: str = (
        "Analyze evidence for credibility, admissibility, and legal weight. "
        "Evaluates strength of evidence in court proceedings."
    )
    args_schema: Type[BaseModel] = EvidenceAnalyzerInput

    def _run(self, evidence_type: str, evidence_description: str) -> str:
        """
        Analyze evidence credibility and admissibility.
        """
        # Evidence scoring criteria
        analysis = {
            "evidence_type": evidence_type,
            "description": evidence_description,
            "credibility_score": 0,
            "admissibility": "Unknown",
            "legal_weight": "Unknown",
            "concerns": []
        }
        
        # Scoring logic (simplified)
        if evidence_type.lower() == "documentary":
            analysis["credibility_score"] = 85
            analysis["admissibility"] = "Generally admissible under Section 3 of Evidence Act"
            analysis["legal_weight"] = "High - if authenticated"
            if "unsigned" in evidence_description.lower():
                analysis["concerns"].append("Document lacks signature/authentication")
                analysis["credibility_score"] -= 20
        
        elif evidence_type.lower() == "testimonial":
            analysis["credibility_score"] = 70
            analysis["admissibility"] = "Admissible if witness is competent"
            analysis["legal_weight"] = "Medium - subject to cross-examination"
            if "hearsay" in evidence_description.lower():
                analysis["concerns"].append("May be hearsay - limited admissibility")
                analysis["credibility_score"] -= 30
        
        elif evidence_type.lower() == "physical":
            analysis["credibility_score"] = 90
            analysis["admissibility"] = "Admissible if chain of custody maintained"
            analysis["legal_weight"] = "High - tangible evidence"
            if "chain of custody" in evidence_description.lower():
                analysis["concerns"].append("Verify unbroken chain of custody")
        
        elif evidence_type.lower() == "digital":
            analysis["credibility_score"] = 75
            analysis["admissibility"] = "Admissible under Section 65B of Evidence Act"
            analysis["legal_weight"] = "Medium-High - if certified properly"
            analysis["concerns"].append("Must comply with Section 65B certificate requirements")
        
        # Format output
        output = f"""**Evidence Analysis Report**

Evidence Type: {analysis['evidence_type']}
Description: {analysis['description']}

Credibility Score: {analysis['credibility_score']}/100
Admissibility: {analysis['admissibility']}
Legal Weight: {analysis['legal_weight']}

Concerns:
{chr(10).join(f"- {concern}" for concern in analysis['concerns']) if analysis['concerns'] else "- None identified"}

Recommendation: {"STRONG EVIDENCE" if analysis['credibility_score'] >= 80 else "MODERATE EVIDENCE" if analysis['credibility_score'] >= 60 else "WEAK EVIDENCE - Use with caution"}
"""
        return output

# Create instance
evidence_analyzer_tool = EvidenceAnalyzerTool()
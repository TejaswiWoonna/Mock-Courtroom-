"""
A2A Protocol Integration for Courtroom (Requirement #5)
This uses a simple LLM-based "advisor agent" for A2A communication
Works with Gemini API - Fast and reliable!
"""
import os
from typing import Dict, Any
from crewai import Agent, Task, Crew, LLM
from crewai.tools import BaseTool
from pydantic import BaseModel, Field


# ============= SIMULATED ADK AGENT USING GEMINI =============

class LegalAdvisorAgent:
    """
    Simulated ADK-style agent using Gemini LLM
    This demonstrates A2A protocol with Gemini API
    """
    
    def __init__(self):
        """Initialize the advisor agent with Gemini"""
        self.llm = LLM(
            model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro
            api_key=os.getenv("GEMINI_API_KEY"),
            temperature=0.5,
            max_tokens=512  # ✅ Increased for Gemini
        )
        
        # Create a specialized legal advisor agent
        self.agent = Agent(
            role="Senior Legal Advisor (A2A Agent)",
            goal="Provide expert legal consultation to other agents via A2A protocol",
            backstory="""You are a distinguished legal scholar and retired Supreme Court judge
            with 30 years of experience. You provide expert second opinions on complex legal matters.
            
            Your expertise includes:
            - Indian Constitutional Law
            - Criminal Law and Procedure
            - Precedent analysis
            - Legal strategy consultation
            
            You communicate via A2A (Agent-to-Agent) protocol, providing concise expert opinions.""",
            llm=self.llm,
            verbose=False
        )
        
        self.consultation_history = []
    
    def consult(self, query: str, context: Dict[str, Any] = None) -> str:
        """
        A2A Protocol Consultation
        
        Args:
            query: Legal question from CrewAI agent
            context: Additional context (case details, round number, etc.)
            
        Returns:
            Expert legal opinion
        """
        # Build consultation task
        context_str = ""
        if context:
            context_str = "\n\nContext:\n" + "\n".join(
                f"- {k}: {v}" for k, v in context.items()
            )
        
        task = Task(
            description=f"""Provide expert legal consultation on this query:

{query}
{context_str}

Your response must include:
1. Legal Opinion: Your expert view
2. Relevant Precedent: Cite specific case law
3. Strategic Advice: Practical recommendation

Keep response concise (4-5 sentences).""",
            expected_output="Expert legal consultation with opinion, precedent, and advice",
            agent=self.agent
        )
        
        # Execute consultation (A2A communication happens here)
        crew = Crew(agents=[self.agent], tasks=[task], verbose=False)
        result = crew.kickoff()
        
        # Log this A2A communication
        self.consultation_history.append({
            "query": query,
            "context": context,
            "response": str(result.raw),
            "timestamp": __import__('datetime').datetime.now().isoformat()
        })
        
        return str(result.raw)
    
    def get_consultation_count(self) -> int:
        """Get total A2A consultations"""
        return len(self.consultation_history)


# ============= GLOBAL A2A ADVISOR INSTANCE =============

# Create single global instance for A2A communications
a2a_advisor = LegalAdvisorAgent()


# ============= CREWAI TOOL FOR A2A CONSULTATION =============

class A2AConsultInput(BaseModel):
    """Input schema for A2A consultation"""
    legal_question: str = Field(..., description="Specific legal question for expert advisor")

class A2AConsultationTool(BaseTool):
    """
    Tool for CrewAI agents to consult the A2A Legal Advisor
    Demonstrates inter-agent communication (A2A protocol)
    """
    name: str = "Legal Advisor Consultation (A2A)"
    description: str = """Consult with senior legal advisor via A2A protocol for expert opinions.
    
    Use this when you need:
    - Second opinion on legal strategy
    - Precedent verification
    - Complex legal interpretation
    - Strategic guidance
    
    The advisor is a separate agent (A2A communication)."""
    args_schema: type[BaseModel] = A2AConsultInput
    
    def _run(self, legal_question: str) -> str:
        """Execute A2A consultation"""
        try:
            # A2A PROTOCOL: CrewAI Agent → A2A Advisor Agent
            response = a2a_advisor.consult(legal_question)
            
            return f"""
╔══════════════════════════════════════════════════════════════╗
║  A2A CONSULTATION RESPONSE (from Legal Advisor Agent)        ║
╚══════════════════════════════════════════════════════════════╝

{response}

[Total A2A consultations this session: {a2a_advisor.get_consultation_count()}]
"""
        except Exception as e:
            return f"⚠️ A2A consultation failed: {str(e)}"


# ============= CREATE TOOL INSTANCE =============

a2a_consultation_tool = A2AConsultationTool()


# ============= HELPER FUNCTION FOR LOGGING A2A =============

def log_a2a_communication(from_agent: str, query: str, callback_handler=None):
    """Log A2A communication event"""
    if callback_handler:
        callback_handler.log_event("A2A_COMMUNICATION", {
            "from_agent": from_agent,
            "to_agent": "Legal Advisor (A2A)",
            "query_preview": query[:100]
        })


# ============= USAGE EXAMPLE =============

if __name__ == "__main__":
    print("Testing A2A Protocol (Gemini-based)\n")
    print("="*70)
    
    # Test A2A consultation
    query = """I'm prosecuting a premature release case. The defendant claims 
    he's eligible under the 2014 policy. What's the strongest counter-argument?"""
    
    context = {
        "case": "Rajkumar vs State of UP",
        "round": 3,
        "side": "prosecution"
    }
    
    print("CrewAI Agent Query (via A2A):")
    print(f"  {query}\n")
    print("-"*70)
    
    # A2A communication
    response = a2a_advisor.consult(query, context)
    
    print("\nA2A Advisor Response:")
    print(f"{response}\n")
    print("="*70)
    print("✅ A2A Protocol working!\n")
    print(f"Total A2A consultations: {a2a_advisor.get_consultation_count()}")
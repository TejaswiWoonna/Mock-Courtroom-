import os
from typing import Type, List, Dict, Any, Union
from crewai.tools import BaseTool
from pydantic import BaseModel, Field, field_validator

class LegalSearchInput(BaseModel):
    """Input for legal database search."""
    query: Union[str, Dict[str, Any]] = Field(..., description="Legal query or case law to search for")
    jurisdiction: Union[str, Dict[str, Any]] = Field(default="India", description="Legal jurisdiction")
    
    @field_validator('query', mode='before')
    @classmethod
    def parse_query(cls, v):
        """Extract actual value from dict if schema dict is passed."""
        if isinstance(v, dict):
            # If it's a schema dict, try to extract the description or use a default
            return v.get('description', v.get('value', str(v)))
        return str(v) if v else "general legal query"
    
    @field_validator('jurisdiction', mode='before')
    @classmethod
    def parse_jurisdiction(cls, v):
        """Extract actual value from dict if schema dict is passed."""
        if isinstance(v, dict):
            return v.get('description', v.get('value', str(v)))
        return str(v) if v else "India"

class LegalSearchTool(BaseTool):
    name: str = "Legal Database Search"
    description: str = (
        "Search for legal precedents, case law, and statutes. "
        "Useful for finding supporting legal arguments and citations."
    )
    args_schema: Type[BaseModel] = LegalSearchInput

    def _run(self, query: str, jurisdiction: str = "India") -> str:
        """
        Simulated legal database search.
        In production, this would connect to a real legal database API.
        """
        # Ensure we have strings (validators should have already handled dict inputs)
        query = str(query) if query else "general legal query"
        jurisdiction = str(jurisdiction) if jurisdiction else "India"
        
        # Simulated legal precedents database
        legal_db = {
            "premature release": [
                "Rashidul Jafar @ Chota vs. State of Uttar Pradesh (2022) - Emphasizes liberalized policy for premature release",
                "Union of India vs. V. Sriharan (2016) - Life imprisonment interpretation and remission powers",
                "Laxman Naskar vs. Union of India (2000) - State government's power for premature release"
            ],
            "life imprisonment": [
                "Gopal Vinayak Godse vs. State of Maharashtra (1961) - Life imprisonment means imprisonment for life",
                "Maru Ram vs. Union of India (1981) - Remission and premature release guidelines",
                "Swamy Shraddananda vs. State of Karnataka (2008) - Alternative to death penalty"
            ],
            "prisoner rights": [
                "Sunil Batra vs. Delhi Administration (1978) - Prisoners retain fundamental rights",
                "Charles Sobraj vs. Superintendent (1978) - Rights of undertrial prisoners",
                "Rama Murthy vs. State of Karnataka (1997) - Right to speedy trial"
            ]
        }
        
        # Search for relevant precedents
        results = []
        query_lower = query.lower()
        
        for key, cases in legal_db.items():
            if key in query_lower or any(word in key for word in query_lower.split()):
                results.extend(cases)
        
        if not results:
            results = ["No direct precedents found. Consider general principles of natural justice and constitutional provisions."]
        
        output = f"**Legal Search Results for '{query}' in {jurisdiction}:**\n\n"
        for idx, case in enumerate(results, 1):
            output += f"{idx}. {case}\n"
        
        return output

# Create instance
legal_search_tool = LegalSearchTool()
from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from typing import List
import os
from dotenv import load_dotenv
from src.courtroom.tools.evidence_analyzer_tool import evidence_analyzer_tool
from src.courtroom.tools.a2a_protocol import a2a_consultation_tool
from src.courtroom.tools.legal_search_tool import legal_search_tool

load_dotenv()

llm = LLM(
    model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.7,
    max_tokens=512,  # ✅ Increased for Gemini
)

@CrewBase
class Jury:
    """Jury crew responsible for evaluating evidence and forming verdicts."""

    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def jury_evaluator(self) -> Agent:
        return Agent(
            config=self.agents_config['jury_evaluator'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @agent
    def jury_foreperson(self) -> Agent:
        return Agent(
            config=self.agents_config['jury_foreperson'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @task
    def jury_evaluation_task(self) -> Task:
        return Task(
            config=self.tasks_config['jury_evaluation_task'],
            agent=self.jury_evaluator(),  # ✅ Assigned agent
        )

    @task
    def jury_deliberation_task(self) -> Task:
        return Task(
            config=self.tasks_config['jury_deliberation_task'],
            agent=self.jury_foreperson(),  # ✅ Assigned agent
            context=[self.jury_evaluation_task()],
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
            memory=False,
            max_rpm=10,
        )
from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from typing import List
import os
from dotenv import load_dotenv
from src.courtroom.tools.evidence_analyzer_tool import evidence_analyzer_tool
from src.courtroom.tools.a2a_protocol import a2a_consultation_tool
from src.courtroom.tools.legal_search_tool import legal_search_tool

load_dotenv()

llm = LLM(
    model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.7,
    max_tokens=512,  # ✅ Increased for Gemini
)

@CrewBase
class Reporter:
    """Reporter crew responsible for documenting and summarizing court proceedings."""

    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def court_reporter(self) -> Agent:
        return Agent(
            config=self.agents_config['court_reporter'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @agent
    def media_analyst(self) -> Agent:
        return Agent(
            config=self.agents_config['media_analyst'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @task
    def transcription_task(self) -> Task:
        return Task(
            config=self.tasks_config['transcription_task'],
            agent=self.court_reporter(),  # ✅ Assigned agent
        )

    @task
    def summary_task(self) -> Task:
        return Task(
            config=self.tasks_config['summary_task'],
            agent=self.media_analyst(),  # ✅ Assigned agent
            context=[self.transcription_task()],
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
            memory=False,
            max_rpm=10,
        )
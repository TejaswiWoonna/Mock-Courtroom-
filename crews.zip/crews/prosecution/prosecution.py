import os
from dotenv import load_dotenv
from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from src.courtroom.tools.evidence_analyzer_tool import evidence_analyzer_tool
from src.courtroom.tools.a2a_protocol import a2a_consultation_tool
from src.courtroom.tools.legal_search_tool import legal_search_tool

load_dotenv()

llm = LLM(
    model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro  # ✅ Must match main.py
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.7,
    max_tokens=512,  # ✅ Increased for Gemini
)

@CrewBase
class Prosecution:
    """Prosecution crew"""
    
    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def prosecutor(self) -> Agent:
        return Agent(
            config=self.agents_config['prosecutor'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @agent
    def evidence_gatherer(self) -> Agent:
        return Agent(
            config=self.agents_config['evidence_gatherer'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @task
    def gather_evidence(self) -> Task:
        return Task(
            config=self.tasks_config['gather_evidence'],
            agent=self.evidence_gatherer(),
        )

    @task
    def build_prosecution_case(self) -> Task:
        return Task(
            config=self.tasks_config['build_prosecution_case'],
            agent=self.prosecutor(),
            context=[self.gather_evidence()],
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
            memory=False,
            max_rpm=10,
        )
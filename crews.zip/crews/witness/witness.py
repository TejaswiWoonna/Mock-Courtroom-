from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from typing import List
import os
from dotenv import load_dotenv
from src.courtroom.tools.evidence_analyzer_tool import evidence_analyzer_tool
from src.courtroom.tools.a2a_protocol import a2a_consultation_tool
from src.courtroom.tools.legal_search_tool import legal_search_tool

load_dotenv()

llm = LLM(
    model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.7,
    max_tokens=512,  # ✅ Increased for Gemini
)

@CrewBase
class Witness:
    """Witness crew responsible for collecting and analyzing witness testimonies."""

    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def witness_interviewer(self) -> Agent:
        return Agent(
            config=self.agents_config['witness_interviewer'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @agent
    def witness_analyst(self) -> Agent:
        return Agent(
            config=self.agents_config['witness_analyst'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @task
    def witness_interview_task(self) -> Task:
        return Task(
            config=self.tasks_config['witness_interview_task'],
            agent=self.witness_interviewer(),  # ✅ Assigned agent
        )

    @task
    def witness_analysis_task(self) -> Task:
        return Task(
            config=self.tasks_config['witness_analysis_task'],
            agent=self.witness_analyst(),  # ✅ Assigned agent
            context=[self.witness_interview_task()],
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
            memory=False,
            max_rpm=10,
        )
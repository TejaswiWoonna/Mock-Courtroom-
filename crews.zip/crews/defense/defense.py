from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from typing import List
import os
from dotenv import load_dotenv
from src.courtroom.tools.legal_search_tool import legal_search_tool
from src.courtroom.tools.evidence_analyzer_tool import evidence_analyzer_tool
from src.courtroom.tools.a2a_protocol import a2a_consultation_tool


load_dotenv()

llm = LLM(
    model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.7,
    max_tokens=512,  # ✅ Increased for Gemini
)

@CrewBase
class Defense:
    """Defense crew responsible for preparing the defense arguments and strategy."""

    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def defense_researcher(self) -> Agent:
        return Agent(
            config=self.agents_config['defense_researcher'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @agent
    def defense_analyst(self) -> Agent:
        return Agent(
            config=self.agents_config['defense_analyst'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @task
    def defense_research_task(self) -> Task:
        return Task(
            config=self.tasks_config['defense_research_task'],
            agent=self.defense_researcher(),  # ✅ Assigned agent
        )

    @task
    def defense_report_task(self) -> Task:
        return Task(
            config=self.tasks_config['defense_report_task'],
            agent=self.defense_analyst(),  # ✅ Assigned agent
            context=[self.defense_research_task()],  # ✅ Context instead of depends_on
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
            memory=False,
            max_rpm=10,
        )
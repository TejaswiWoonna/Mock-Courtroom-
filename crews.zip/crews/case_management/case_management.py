import os
import time
from typing import List
from dotenv import load_dotenv
from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from crewai.agents.agent_builder.base_agent import BaseAgent
from src.courtroom.tools.file_parser_tool import file_parser_tool
from src.courtroom.tools.legal_search_tool import legal_search_tool
from src.courtroom.tools.evidence_analyzer_tool import evidence_analyzer_tool
from src.courtroom.tools.a2a_protocol import a2a_consultation_tool

# === Load environment variables ===
load_dotenv()

# === Initialize Gemini LLM ===
llm = LLM(
    model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.5,
    max_tokens=512,   # ✅ Increased for Gemini
)

@CrewBase
class CaseManagement:
    """CaseManagement crew — SIMPLIFIED to 1 task only."""

    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def case_preparer(self) -> Agent:
        """Agent responsible for loading case data - SIMPLIFIED."""
        return Agent(
            config=self.agents_config['case_preparer'],
            tools=[file_parser_tool],  # ✅ ONLY file parser tool - removed others
            llm=llm,
            verbose=False,  # ✅ Less verbose = faster
            max_iter=1,     # ✅ CRITICAL: Only 1 iteration
            max_retry_limit=1,
            allow_delegation=False,  # ✅ No delegation
        )

    @task
    def load_case_data(self) -> Task:
        """Task: Load case data - SINGLE TASK ONLY."""
        return Task(
            config=self.tasks_config['load_case_data'],
            agent=self.case_preparer(),
        )

    # ✅ REMOVED generate_case_summary task to save tokens!

    @crew
    def crew(self) -> Crew:
        """Creates the CaseManagement crew - SINGLE TASK."""
        return Crew(
            agents=[self.case_preparer()],  # ✅ Only 1 agent
            tasks=[self.load_case_data()],  # ✅ Only 1 task
            process=Process.sequential,
            verbose=False,  # ✅ Less logging
            memory=False,
            max_rpm=5,  # ✅ Reduced from 10 to 5
        )


# === Retry Wrapper with LONGER delays ===
def run_with_retry(case_name="Rajkumar", max_retries=3, delay=30):  # ✅ 30 second delay
    """Run CaseManagement crew with retries and rate limit protection."""
    attempt = 0
    
    # ✅ Wait at start to clear any previous rate limits
    print("⏸️  Initial cooldown: waiting 20 seconds...")
    time.sleep(20)
    
    while attempt < max_retries:
        try:
            print(f"\n🚀 Attempt {attempt + 1}/{max_retries} - Loading case: {case_name}\n")
            
            crew_instance = CaseManagement().crew()
            result = crew_instance.kickoff(inputs={"case_name": case_name})
            
            print("\n✅ Case loaded successfully!\n")
            print("\n📄 Result:\n")
            print(result)
            return result
            
        except Exception as e:
            error_msg = str(e).lower()
            
            # Check if it's a rate limit error
            if "rate limit" in error_msg or "429" in error_msg:
                print(f"⚠️ Rate limit hit on attempt {attempt + 1}")
                wait_time = delay * (attempt + 1)  # Exponential backoff
                print(f"⏸️  Waiting {wait_time} seconds before retry...")
                time.sleep(wait_time)
            else:
                print(f"⚠️ Error on attempt {attempt + 1}: {e}")
                time.sleep(delay)
            
            attempt += 1
            
            if attempt >= max_retries:
                print("\n❌ Max retries reached. Returning partial result.\n")
                # ✅ Return a fallback instead of crashing
                return {
                    "status": "failed",
                    "case_name": case_name,
                    "error": str(e),
                    "message": "Case data could not be loaded due to rate limits. Using fallback."
                }


if __name__ == "__main__":
    run_with_retry()
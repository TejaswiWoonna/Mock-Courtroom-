from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task
from typing import List
import os
from dotenv import load_dotenv
from src.courtroom.tools.evidence_analyzer_tool import evidence_analyzer_tool
from src.courtroom.tools.a2a_protocol import a2a_consultation_tool
from src.courtroom.tools.legal_search_tool import legal_search_tool

load_dotenv()

llm = LLM(
    model="gemini/gemini-2.5-flash",  # ✅ Changed to gemini-1.5-pro
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.7,
    max_tokens=512,  # ✅ Increased for Gemini
)

@CrewBase
class Judge:
    """Judge crew — responsible for reviewing case materials and generating judgments."""

    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def case_reviewer(self) -> Agent:
        return Agent(
            config=self.agents_config['case_reviewer'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @agent
    def legal_writer(self) -> Agent:
        return Agent(
            config=self.agents_config['legal_writer'],
            llm=llm,
            verbose=True,
            max_iter=8,
            max_retry_limit=2,
            tools=[legal_search_tool, evidence_analyzer_tool, a2a_consultation_tool],
        )

    @task
    def review_case_task(self) -> Task:
        return Task(
            config=self.tasks_config['review_case_task'],
            agent=self.case_reviewer(),  # ✅ Assigned agent
        )

    @task
    def judgment_drafting_task(self) -> Task:
        return Task(
            config=self.tasks_config['judgment_drafting_task'],
            agent=self.legal_writer(),  # ✅ Assigned agent
            context=[self.review_case_task()],
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
            memory=False,
            max_rpm=10,
        )